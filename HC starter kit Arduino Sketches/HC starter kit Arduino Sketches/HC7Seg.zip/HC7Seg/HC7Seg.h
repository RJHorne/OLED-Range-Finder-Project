/* FILE:    HC7Seg.h
   DATE:    12/10/16
   VERSION: 0.1
   AUTHOR:  Andrew Davies


21/01/16 version 0.1: Original version

Library for 7 segment LED modules. This Arduino library was written
specifically to support the following Hobby Components product(s):

1-DIGIT 7-SEGMENT LED MODULE SKU: HCOPTO0012
4-DIGIT 7-SEGMENT LED MODULE SKU: HCOPTO0013


You may copy, alter and reuse this code in any way you like, but please leave
reference to HobbyComponents.com in your comments if you redistribute this code.
This software may not be used directly for the purpose of selling products that
directly compete with Hobby Components Ltd's own range of products.
THIS SOFTWARE IS PROVIDED "AS IS". HOBBY COMPONENTS MAKES NO WARRANTIES, WHETHER
EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, ACCURACY OR LACK OF NEGLIGENCE.
HOBBY COMPONENTS SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR ANY DAMAGES,
INCLUDING, BUT NOT LIMITED TO, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY
REASON WHATSOEVER.
*/


#ifndef HC7Seg_h
#define HC7Seg_h

#include "Arduino.h"

/* Supported seven segment led display configurations */
#define COM_ANODE_1DIG 0
#define COM_ANODE_2DIG 1
#define COM_ANODE_3DIG 2
#define COM_ANODE_4DIG 3
#define COM_ANODE_5DIG 4
#define COM_ANODE_6DIG 5
#define COM_ANODE_7DIG 6
#define COM_ANODE_8DIG 7
#define COM_CATHODE_1DIG 8
#define COM_CATHODE_2DIG 9
#define COM_CATHODE_3DIG 10
#define COM_CATHODE_4DIG 11
#define COM_CATHODE_5DIG 12
#define COM_CATHODE_6DIG 13
#define COM_CATHODE_7DIG 14
#define COM_CATHODE_8DIG 15


/* Alpha-numeric character set */
const PROGMEM byte SevenSegChar[101] = {0x00, // SPACE
		0x82, // !
		0x22, // "
		0x36, // #
		0x69, // $
		0x2D, // %
		0x7B, // &
		0x20, // '
		0x39, // (
		0x0F, // )
		0x63, // *
		0x70, // +
		0x0C, //
		0x40, // -
		0x80, // .
		0x52, // /
		0x3F, // 0
		0x06, // 1
		0x5B, // 2
		0x4F, // 3
		0x66, // 4
		0x6D, // 5
		0x7D, // 6
		0x07, // 7
		0x7F, // 8
		0x6F, // 9
		0x48, // :
		0x4C, // ;
		0x61, // <
		0x41, // =
		0x43, // >
		0x53, // ?
		0x5F, // @
		0x77, // A
		0x7C, // B
		0x39, // C
		0x5E, // D
		0x79, // E
		0x71, // F
		0x3D, // G
		0x76, // H
		0x06, // I
		0x0E, // J
		0x75, // K
		0x38, // L
		0x15, // M
		0x37, // N
		0x3F, // O
		0x73, // P
		0x67, // Q
		0x33, // R
		0x6D, // S
		0x78, // T
		0x3E, // U
		0x2E, // V
		0x2A, // W
		0x76, // X
		0x6E, // Y
		0x4B, // Z
		0x39, // [
		0x64, // |
		0x0F, // ]
		0x23, // ^
		0x08, // _
		0x20, // '
		0x77, // a
		0x7C, // b
		0x39, // c
		0x5E, // d
		0x79, // e
		0x71, // f
		0x3D, // g
		0x76, // h
		0x06, // i
		0x0E, // j
		0x75, // k
		0x38, // l
		0x15, // m
		0x37, // n
		0x3F, // o
		0x73, // p
		0x67, // q
		0x33, // r
		0x6D, // s
		0x78, // t
		0x3E, // u
		0x2E, // v
		0x2A, // w
		0x76, // x
		0x6E, // y
		0x4B}; // z



/* Timer 2 clock prescalling values */
enum HCT2PreScaller
{
	T2_CLK_DIV_0    = 1,
	T2_CLK_DIV_8    = 2,
	T2_CLK_DIV_32   = 3,
	T2_CLK_DIV_64   = 4,
    T2_CLK_DIV_128  = 5,
    T2_CLK_DIV_256  = 6,
    T2_CLK_DIV_1024 = 7
};



/* Initiliasation function which reprogrammes timer 2 */
void HCTimer2Init(byte prescaler, byte compare);




class HC7Seg
{
  public:
  HC7Seg(byte Type, byte SegA, byte SegB, byte SegC, byte SegD, byte SegE, byte SegF, byte SegG, byte SegDP, byte Dig1, byte Dig2 = 0xFF, byte Dig3 = 0xFF, byte Dig4 = 0xFF, byte Dig5 = 0xFF, byte Dig6 = 0xFF, byte Dig7 = 0xFF, byte Dig8 = 0xFF);
  void _Output(byte Digit);
  void print7Seg(char TextString[], unsigned int Offset, boolean DP = false);
  void print7Seg(float value, byte Offset, byte DecimalPlaces, boolean DP = true);
  void SetDigit(byte Digit, byte Data);
  void clear(void);

  private:
};

#endif
