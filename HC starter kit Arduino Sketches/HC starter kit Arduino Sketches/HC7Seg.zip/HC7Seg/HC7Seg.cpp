/* FILE:    HC7Seg.cpp
   DATE:    12/10/16
   VERSION: 0.1
   AUTHOR:  Andrew Davies


21/01/16 version 0.1: Original version

Library for 7 segment LED modules. This Arduino library was written
specifically to support the following Hobby Components product(s):

1-DIGIT 7-SEGMENT LED MODULE SKU: HCOPTO0012
4-DIGIT 7-SEGMENT LED MODULE SKU: HCOPTO0013


You may copy, alter and reuse this code in any way you like, but please leave
reference to HobbyComponents.com in your comments if you redistribute this code.
This software may not be used directly for the purpose of selling products that
directly compete with Hobby Components Ltd's own range of products.
THIS SOFTWARE IS PROVIDED "AS IS". HOBBY COMPONENTS MAKES NO WARRANTIES, WHETHER
EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, ACCURACY OR LACK OF NEGLIGENCE.
HOBBY COMPONENTS SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR ANY DAMAGES,
INCLUDING, BUT NOT LIMITED TO, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY
REASON WHATSOEVER.
*/

#include "Arduino.h"
#include "HC7Seg.h"

#include <avr/io.h>
#include <avr/interrupt.h>


  byte _Seg[8]; 			// Holds the pin numbers used to control each LED segment
  byte _Dig[8];				// Holds the pin numbers used to control each digit
  byte _NumOfDigits;		// Stores the number of digits (1 to 8);
  byte SegBuffer[8];		// Output buffer which holds the segment information for each digit
  byte _DigitIndex  = 0;	// Holds the digit number that its currently being driven
  boolean _ComAnode;		// Used to store the type of LED array. True = common anode, false = common cathode.


/* Constructor to initiliase the GPIO as outputs and in the OFF state*/
HC7Seg::HC7Seg(byte Type, byte SegA, byte SegB, byte SegC, byte SegD, byte SegE, byte SegF, byte SegG, byte SegDP, byte Dig1, byte Dig2, byte Dig3, byte Dig4, byte Dig5, byte Dig6, byte Dig7, byte Dig8)
{

	/* Store the segment pins */
	_Seg[0] = SegA;
	_Seg[1] = SegB;
	_Seg[2] = SegC;
	_Seg[3] = SegD;
	_Seg[4] = SegE;
	_Seg[5] = SegF;
	_Seg[6] = SegG;
	_Seg[7] = SegDP;


	/* Set the number of digits and LED type */
	switch(Type)
	{
		case(COM_ANODE_1DIG):
			_NumOfDigits = 1;
			_ComAnode = true;
			break;
		case(COM_ANODE_2DIG):
			_NumOfDigits = 2;
			_ComAnode = true;
			break;
		case(COM_ANODE_3DIG):
			_NumOfDigits = 3;
			_ComAnode = true;
			break;
		case(COM_ANODE_4DIG):
			_NumOfDigits = 4;
			_ComAnode = true;
			break;
		case(COM_ANODE_5DIG):
			_NumOfDigits = 5;
			_ComAnode = true;
			break;
		case(COM_ANODE_6DIG):
			_NumOfDigits = 6;
			_ComAnode = true;
			break;
		case(COM_ANODE_7DIG):
			_NumOfDigits = 7;
			_ComAnode = true;
			break;
		case(COM_ANODE_8DIG):
			_NumOfDigits = 8;
			_ComAnode = true;
			break;

		case(COM_CATHODE_1DIG):
			_NumOfDigits = 1;
			_ComAnode = false;
			break;
		case(COM_CATHODE_2DIG):
			_NumOfDigits = 2;
			_ComAnode = false;
			break;
		case(COM_CATHODE_3DIG):
			_NumOfDigits = 3;
			_ComAnode = false;
			break;
		case(COM_CATHODE_4DIG):
			_NumOfDigits = 4;
			_ComAnode = false;
			break;
		case(COM_CATHODE_5DIG):
			_NumOfDigits = 5;
			_ComAnode = false;
			break;
		case(COM_CATHODE_6DIG):
			_NumOfDigits = 6;
			_ComAnode = false;
			break;
		case(COM_CATHODE_7DIG):
			_NumOfDigits = 7;
			_ComAnode = false;
			break;
		case(COM_CATHODE_8DIG):
			_NumOfDigits = 8;
			_ComAnode = false;
			break;
	}

	/* Store the digit pins */
	_Dig[0] = Dig1;
	_Dig[1] = Dig2;
	_Dig[2] = Dig3;
	_Dig[3] = Dig4;
	_Dig[4] = Dig5;
	_Dig[5] = Dig6;
	_Dig[6] = Dig7;
	_Dig[7] = Dig8;


	/* Set segment pins to outputs with LED off */
	for(byte i = 0; i < 8; i++)
	{
		pinMode(_Seg[i], OUTPUT);
		digitalWrite(_Seg[i], _ComAnode);
	}

	/* Set digit pins to outputs with LED off */
	for(byte i = 0; i < _NumOfDigits; i++)
	{
		pinMode(_Dig[i], OUTPUT);
		digitalWrite(_Dig[i], !_ComAnode);
	}


	/* Clear the output buffer */
	clear();

	/* Initiliase the HCTimer2 library with a 15.616mS interval */
	  HCTimer2Init(T2_CLK_DIV_256, 255);


}



/* Writes a byte of data to the output buffer where:
   Digit is which digit number on the display to write to

   Data is an 8 bit number where each bit represents one of the digits segments */
void HC7Seg::SetDigit(byte Digit, byte Data)
{
	if(Digit < _NumOfDigits)
		SegBuffer[Digit] = Data;
}



/* Prints a string of text to the display at a specified position where:
   TextString[] is a character array containing the text to print.

   Offset is the digit position from where the text will start.
   	   1 = the right most digit, 2 = second right most digit, etc. Characters can also be positioned off display.

   DP is an optional parameter (default = false) which specifies if to use the seven segments DP led to represent full stops and decimal points. Valid values for DP are
   	   false = full stops and decimal points will take up a whole digit on the display.
   	   true = full stops and decimal points will use the DP segment on the preceding character/number.
   */
void HC7Seg::print7Seg(char TextString[], unsigned int Offset, boolean DP)
{
  int _StringLength;
  unsigned int bufferindex;
  int charindex;
  char character;

  _StringLength = strlen(TextString);

  if(DP)
  {
	  bufferindex = 0;
	  for(charindex = 0; charindex <= _StringLength; charindex++)
	  {
		  if(TextString[charindex + 1] == '.')
		  {
			  TextString[bufferindex] = TextString[charindex] | 0x80;
			  charindex++;
		  }else
		  {
			  TextString[bufferindex] = TextString[charindex];
		  }
		  bufferindex++;
	  }
  }

  _StringLength = strlen(TextString);


  /* Set output buffer pointer */
  if(Offset < _NumOfDigits)
  {
    bufferindex = Offset;
  }else
  {
    bufferindex = _NumOfDigits;
  }

  /* If text runs beyond the output buffer then crop it */
  charindex = 0;
  if (Offset > _NumOfDigits)
    charindex = Offset - (_NumOfDigits);


  /* Copy text into output buffer */
  while(bufferindex != 0 && charindex >= 0 && charindex < _StringLength)
  {
     bufferindex--;

     if(TextString[charindex] & 0x80)
    	 character = pgm_read_byte_near(&SevenSegChar[(TextString[charindex] & 0x7F) - 32]) | 0x80;
     else
    	 character = pgm_read_byte_near(&SevenSegChar[TextString[charindex] - 32]);


     SegBuffer[bufferindex] = character;
     charindex++;
  }
}




/* Prints a signed decimal number to the display where:
   Value is the signed floating point number to display

   Offset is the digit position from where the text will start.
   	   1 = the right most digit, 2 = second right most digit, etc. Characters can also be positioned off display.

   DecimalPlaces is optional and set number of decimal places to display the number to.

   DP is an optional parameter (default = true) which specifies if to use the seven segments DP led to represent full stops and decimal points. Valid values for DP are
   	   false = full stops and decimal points will take up a whole digit on the display.
   	   true = full stops and decimal points will use the DP segment on the preceding character/number. */


void HC7Seg::print7Seg(float value, byte Offset, byte DecimalPlaces, boolean DP)
{
	char Buffer[10];

	/* Convert the value to an character array */
	dtostrf(value, 0, DecimalPlaces, Buffer);

	/* Output the array to the display buffer */
	print7Seg(Buffer, Offset, DP);
}




/* Clears the output buffer and display (turns off all LEDS) */
void HC7Seg::clear(void)
{
	for(byte i = 0; i < _NumOfDigits; i++)
		SegBuffer[i] = 0;
}





/* Writes a digit from the SegBuffer buffer to the pins */
void _Output(byte Digit)
{
	/* Turn off all digits before changing segments so not to cause ghosting effect */
	for(byte i = 0; i < _NumOfDigits; i++)
	{
			digitalWrite(_Dig[i], !_ComAnode);
	}

	/* Turn on/off the segments for that digit */
	for(byte i = 0; i < 8; i++)
	{
		if(_ComAnode)
			digitalWrite(_Seg[i], !((SegBuffer[Digit] >> i) & 1));
		else
			digitalWrite(_Seg[i], (SegBuffer[Digit] >> i) & 1);
	}

	/* Select the next digit */
	for(byte i = 0; i < _NumOfDigits; i++)
	{
		digitalWrite(_Dig[Digit], _ComAnode);
	}
}



/* Sets up the timer 2 interrupt so that the display can be refreshed in the background */
void HCTimer2Init(byte prescaler, byte compare)
{
	/* Turn off interrupts whilst we setup the timer */
	cli();
	/* Set timer mode to clear timer on compare match (mode 2)*/
	TCCR2A = (1<<WGM21);

	/* Set the prescaler */
	TCCR2B = prescaler;

	/* Clear timer 2 counter */
	TCNT2 = 0;

	/* Set the compare match register */
	OCR2A = compare;

	/* Enable timer 2 interrupt on compare match */
	TIMSK2 = (1<<OCIE2A);

  	/* Turn interrupts back on */
  	sei();
}



/* Interrupt service routine for Timer 2 compare match */
ISR(TIMER2_COMPA_vect)
{
	_Output(_DigitIndex);
	_DigitIndex++;
	if(_DigitIndex == _NumOfDigits)
		_DigitIndex = 0;
}

